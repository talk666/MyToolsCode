#include "stdio.h"
#include "stdlib.h"

//任务一
int a1(int i)
{
	printf("%d\r\n",i);
    return 0;
}
//.....
int a2(int i)
{
	printf("%d\r\n",i + 1);
    return 0;
}
int a3(int i)
{
	printf("%d\r\n",i + 2);
    return 0;
}
int a4(int i)
{
	printf("%d\r\n",i + 3);
    return 0;
}
int a5(int i)
{
	printf("%d\r\n",i + 4);
    return 0;
}