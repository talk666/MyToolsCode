#ifndef _TEST_
#define _TEST_
#include "util.h"

struct test 
{
    int index;
    int key;
    int (*func)(int);
};

struct test a[] = {
	{0,30,a1},{1,1,a2},{2,2,a3},{3,3,a4},{4,4,a5}
};

#endif
