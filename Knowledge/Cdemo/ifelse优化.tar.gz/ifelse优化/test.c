#include <stdio.h>
#include <stdlib.h>
#include "test.h"

// int main()
// {
// 	int i;
// 	scanf("%d",&i);
// 	if(i == 0)
// 		printf("00");
// 	if(i == 1)
// 		printf("01");
// 	if(i == 2)
// 		printf("02");
// 	if(i == 3)
// 		printf("03");
// }

// int input(struct test *a)
// {
// 	a[0].index = 0;
// 	a[0].key = 0;
// 	a[1].index = 1;
// 	a[1].key = 1;
// 	a[2].index = 2;
// 	a[2].key = 2;

// 	return 0;
// }



int main()
{
	unsigned int i;
	int j;
	
	// struct test a[5];
	// input(a);
	while(1)
	{	
		scanf("%d",&j);
		// printf("%d\r\n",sizeof(a)/sizeof(a[0]));
		for(i = 0; i < sizeof(a)/sizeof(a[0]); i++)
		{
			if(j == a[i].index)
			{
				printf("%d\r\n",a[j].key);
				a[j].func(i);
			}
		}
	}

}

