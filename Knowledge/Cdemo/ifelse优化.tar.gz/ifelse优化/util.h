#ifndef _UTIL_
#define _UTIL_


int a1(int i);
int a2(int i);
int a3(int i);
int a4(int i);
int a5(int i);

#endif